package com.makoto.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val MakotoDarkColors = darkColorScheme(
    primary = MakotoPurple,
    secondary = MakotoLavender,
    background = MakotoBlack,
    surface = MakotoSurface,
    surfaceVariant = MakotoSurfaceVariant
)

@Composable
fun MakotoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MakotoDarkColors,
        typography = MakotoTypography,
        content = content
    )
}
