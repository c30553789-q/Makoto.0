package com.makoto.app.ai

import com.makoto.app.data.ChatMessage
import com.makoto.app.data.MemoryItem

/**
 * Arma el prompt en formato ChatML (SmolLM2 / similares).
 * Mantiene el historial corto para no explotar la RAM.
 */
object PromptBuilder {

    private const val SYSTEM = """Eres Makoto, una asistente local, cercana y útil. Responde en el idioma del usuario. Sé concisa cuando baste."""

    fun build(
        userText: String,
        history: List<ChatMessage>,
        memory: List<MemoryItem>,
        maxHistoryMessages: Int = 8,
        maxHistoryChars: Int = 3000
    ): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n")
        sb.append(SYSTEM)
        if (memory.isNotEmpty()) {
            sb.append("\n\nNotas de memoria local:\n")
            memory.take(8).forEach { sb.append("- ").append(it.text).append('\n') }
        }
        sb.append("<|im_end|>\n")

        // Historial corto y con tope de caracteres: menos tokens = respuestas más rápidas
        var budget = maxHistoryChars
        val recent = ArrayList<ChatMessage>()
        for (m in history.takeLast(maxHistoryMessages).asReversed()) {
            if (budget - m.text.length < 0 && recent.isNotEmpty()) break
            budget -= m.text.length
            recent.add(m)
        }
        recent.reverse()
        for (m in recent) {
            if (m.fromUser) {
                sb.append("<|im_start|>user\n").append(m.text).append("<|im_end|>\n")
            } else {
                sb.append("<|im_start|>assistant\n").append(m.text).append("<|im_end|>\n")
            }
        }
        sb.append("<|im_start|>user\n").append(userText.take(4000)).append("<|im_end|>\n")
        // Bloque vacío de "pensar": evita que Qwen3.x gaste tiempo razonando antes de responder
        sb.append("<|im_start|>assistant\n<think>\n\n</think>\n\n")
        return sb.toString()
    }
}
