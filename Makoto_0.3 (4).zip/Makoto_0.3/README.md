# Makoto 0.3 — Cerebro local

Cuerpo 0.2 + motor GGUF local (llama.cpp vía JNI).

## Qué incluye
- Todo el cuerpo 0.2 (chat, historial, memoria, papelera, SAF)
- Motor `LlamaCppEngine` (CPU, arm64-v8a)
- Contexto 2048, máx. 512 tokens por respuesta, 2–4 hilos
- Prompt ChatML + memoria local
- Workflow de GitHub Actions que clona llama.cpp y compila el APK

## Modelo
Pon un GGUF (p. ej. SmolLM2-1.7B-Instruct Q4_K_M) en una carpeta de la tablet
y selecciónala en Configuración. **Nunca** dentro del APK.

## Compilar (GitHub Actions)
1. Sube este proyecto a un repo (o el ZIP + workflow que descomprime).
2. Actions → **Build Makoto APK**.
3. Descarga el artefacto `makoto-0.3-debug`.

## Hardware
Tablet Android 14, ~7 GB RAM, arm64. Solo CPU. Puede ir lento; es normal.

## Compilar en GitHub Actions

1. Crea un repositorio en GitHub y sube el contenido de esta carpeta al nivel raíz, **o** sube únicamente el ZIP `Makoto_0.3.zip` al nivel raíz.
2. Abre la pestaña **Actions**.
3. Selecciona **Build Makoto APK** y pulsa **Run workflow**.
4. Deja `b10502` como referencia de `llama.cpp` y ejecuta el flujo.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto `makoto-0.3-debug`.

El flujo compila para Android `arm64-v8a` con JDK 17, Android SDK 36, NDK 27.2.12479018 y CMake 3.22.1. El GGUF no se incluye en el APK.

**Importante:** que GitHub genere el APK no garantiza todavía que todos los proveedores de archivos de Android permitan cargar el GGUF mediante su descriptor SAF. Esa ruta debe probarse en la tablet con un archivo local real. El proyecto no copia automáticamente un modelo de gran tamaño a otra ubicación para evitar duplicar cientos de MB o GB.
