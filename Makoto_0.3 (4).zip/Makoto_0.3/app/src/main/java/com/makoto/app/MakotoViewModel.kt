package com.makoto.app

import android.app.Application
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.makoto.app.ai.InferenceEngine
import com.makoto.app.ai.LlamaCppEngine
import com.makoto.app.ai.PromptBuilder
import com.makoto.app.ai.UnavailableInferenceEngine
import com.makoto.app.data.ChatMessage
import com.makoto.app.data.Conversation
import com.makoto.app.data.MemoryItem
import com.makoto.app.model.ConversationRepository
import com.makoto.app.model.MemoryRepository
import com.makoto.app.model.ModelManager
import com.makoto.app.storage.JsonStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MakotoViewModel(application: Application) : AndroidViewModel(application) {

    private val store = JsonStore(application)
    private val conversations = ConversationRepository(store)
    private val memoryRepo = MemoryRepository(store)
    private val modelManager = ModelManager(application)

    private val engine: InferenceEngine = try {
        LlamaCppEngine()
    } catch (t: Throwable) {
        UnavailableInferenceEngine()
    }

    private var modelFd: ParcelFileDescriptor? = null
    private var generationJob: Job? = null

    private val _active = MutableStateFlow<List<Conversation>>(emptyList())
    val active: StateFlow<List<Conversation>> = _active.asStateFlow()

    private val _trash = MutableStateFlow<List<Conversation>>(emptyList())
    val trash: StateFlow<List<Conversation>> = _trash.asStateFlow()

    private val _memory = MutableStateFlow<List<MemoryItem>>(emptyList())
    val memory: StateFlow<List<MemoryItem>> = _memory.asStateFlow()

    private val _selectedId = MutableStateFlow(0L)
    val selectedId: StateFlow<Long> = _selectedId.asStateFlow()

    private val _selectedTree = MutableStateFlow<Uri?>(null)
    val selectedTree: StateFlow<Uri?> = _selectedTree.asStateFlow()

    private val _modelCount = MutableStateFlow(0)
    val modelCount: StateFlow<Int> = _modelCount.asStateFlow()

    private val _modelScanError = MutableStateFlow<String?>(null)
    val modelScanError: StateFlow<String?> = _modelScanError.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status.asStateFlow()

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    init {
        _selectedTree.value = modelManager.getSavedTree()
        refreshAll()
        scanModels()
    }

    fun refreshAll() {
        viewModelScope.launch {
            val (activeList, trashList, memList) = withContext(Dispatchers.IO) {
                Triple(conversations.all(), conversations.trash(), memoryRepo.all())
            }
            _active.value = activeList
            _trash.value = trashList
            _memory.value = memList
            if (activeList.isEmpty()) {
                createConversationInternal("Nueva conversación")
            } else if (_selectedId.value == 0L || activeList.none { it.id == _selectedId.value }) {
                _selectedId.value = activeList.first().id
            }
        }
    }

    fun selectConversation(id: Long) {
        _selectedId.value = id
    }

    fun createConversation(title: String = "Nueva conversación") {
        viewModelScope.launch { createConversationInternal(title) }
    }

    private suspend fun createConversationInternal(title: String) {
        val newId = withContext(Dispatchers.IO) {
            val id = maxOf(System.currentTimeMillis(), (_active.value.maxOfOrNull { it.id } ?: 0L) + 1L)
            conversations.save(Conversation(id, title, emptyList()))
            id
        }
        _selectedId.value = newId
        refreshAll()
    }

    fun sendMessage(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || _isGenerating.value) return
        val currentId = _selectedId.value
        if (currentId == 0L) return

        generationJob = viewModelScope.launch {
            _isGenerating.value = true
            _status.value = "Pensando…"
            try {
                // 1) Guardar mensaje del usuario
                val historyAfterUser = withContext(Dispatchers.IO) {
                    val current = conversations.all().firstOrNull { it.id == currentId } ?: return@withContext null
                    val baseId = (current.messages.maxOfOrNull { it.id } ?: System.currentTimeMillis()) + 1L
                    val updated = current.copy(
                        messages = current.messages + ChatMessage(baseId, clean, true)
                    )
                    conversations.save(updated)
                    updated
                } ?: return@launch
                refreshAll()

                // 2) Asegurar modelo
                val loaded = ensureModelLoaded()
                if (!loaded) {
                    appendAssistant(currentId, "No pude cargar el modelo GGUF. Revisa la carpeta en Configuración.")
                    return@launch
                }

                // 3) Generar
                val prompt = PromptBuilder.build(
                    userText = clean,
                    history = historyAfterUser.messages.dropLast(1),
                    memory = _memory.value
                )

                val reply = StringBuilder()
                val genResult = withContext(Dispatchers.Default) {
                    engine.generate(prompt) { token ->
                        if (!isActive) {
                            engine.stop()
                            return@generate
                        }
                        reply.append(token)
                        _partial.value = reply.toString()
                    }
                }
                _partial.value = ""
                if (genResult.isFailure) {
                    appendAssistant(currentId, "Error al generar: ${genResult.exceptionOrNull()?.message}")
                } else {
                    val textOut = reply.toString().ifBlank { "…" }
                    appendAssistant(currentId, textOut)
                }
            } finally {
                _isGenerating.value = false
                _status.value = null
                _partial.value = ""
            }
        }
    }

    private suspend fun appendAssistant(conversationId: Long, text: String) {
        withContext(Dispatchers.IO) {
            val current = conversations.all().firstOrNull { it.id == conversationId } ?: return@withContext
            val baseId = (current.messages.maxOfOrNull { it.id } ?: System.currentTimeMillis()) + 1L
            conversations.save(
                current.copy(messages = current.messages + ChatMessage(baseId, text, false))
            )
        }
        refreshAll()
    }

    private suspend fun ensureModelLoaded(): Boolean = withContext(Dispatchers.IO) {
        if (engine.isReady) return@withContext true
        val tree = _selectedTree.value
        if (tree == null) {
            _status.value = "Selecciona una carpeta de modelos en Configuración."
            return@withContext false
        }
        try {
            _status.value = "Preparando el modelo (la primera vez copia ~1 GB, puede tardar)…"
            val path = modelManager.ensureLocalModel(tree).absolutePath
            val result = engine.loadModel(path)
            if (result.isFailure) {
                _status.value = result.exceptionOrNull()?.message
                false
            } else {
                _status.value = null
                true
            }
        } catch (t: Throwable) {
            _status.value = t.message
            false
        }
    }

    /** Detiene la respuesta en curso conservando lo que ya se generó. */
    fun stopReply() {
        engine.stop()
    }

    fun stopGeneration() {
        engine.stop()
        generationJob?.cancel()
        _isGenerating.value = false
        _status.value = null
    }

    fun moveToTrash(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { conversations.moveToTrash(id) }
            if (_selectedId.value == id) _selectedId.value = 0L
            refreshAll()
        }
    }

    fun restore(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { conversations.restore(id) }
            refreshAll()
        }
    }

    fun permanentlyDelete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { conversations.permanentlyDelete(id) }
            if (_selectedId.value == id) _selectedId.value = 0L
            refreshAll()
        }
    }

    fun addMemory(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { memoryRepo.add(clean) }
            refreshAll()
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { memoryRepo.delete(id) }
            refreshAll()
        }
    }

    fun saveModelTree(uri: Uri) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { modelManager.saveTree(uri) }
            if (result.isSuccess) {
                _selectedTree.value = uri
                _modelScanError.value = null
                // forzar recarga de modelo en el próximo mensaje
                withContext(Dispatchers.IO) {
                    engine.unload()
                    modelFd?.close()
                    modelFd = null
                }
                scanModels()
            } else {
                _modelScanError.value = "No se pudo guardar el acceso a la carpeta: " + (result.exceptionOrNull()?.message ?: "error desconocido")
            }
        }
    }

    fun clearModelTree() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                engine.unload()
                modelFd?.close()
                modelFd = null
                modelManager.clearTree()
            }
            _selectedTree.value = null
            _modelCount.value = 0
            _modelScanError.value = null
        }
    }

    fun scanModels() {
        val tree = _selectedTree.value
        if (tree == null) {
            _modelCount.value = 0
            _modelScanError.value = null
            return
        }
        viewModelScope.launch {
            _modelScanError.value = null
            val result = withContext(Dispatchers.IO) {
                runCatching { modelManager.findGgufFiles(tree).size }
            }
            result
                .onSuccess {
                    _modelCount.value = it
                    _modelScanError.value = null
                }
                .onFailure {
                    _modelCount.value = 0
                    _modelScanError.value =
                        "No se pudo leer la carpeta. Puede que el permiso se haya perdido."
                }
        }
    }

    override fun onCleared() {
        stopGeneration()
        engine.unload()
        runCatching { modelFd?.close() }
        super.onCleared()
    }
}
