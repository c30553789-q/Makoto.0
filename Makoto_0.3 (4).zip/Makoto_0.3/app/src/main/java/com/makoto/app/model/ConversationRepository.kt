package com.makoto.app.model

import com.makoto.app.data.Conversation
import com.makoto.app.storage.JsonStore

class ConversationRepository(private val store: JsonStore) {
    fun all(): List<Conversation> = store.loadConversations().filter { it.deletedAt == null }.sortedByDescending { it.id }
    fun trash(): List<Conversation> = store.loadConversations().filter { it.deletedAt != null }.sortedByDescending { it.deletedAt }
    fun save(conversation: Conversation) = persist(store.loadConversations().filterNot { it.id == conversation.id } + conversation)
    fun moveToTrash(id: Long) = update(id) { it.copy(deletedAt = System.currentTimeMillis()) }
    fun restore(id: Long) = update(id) { it.copy(deletedAt = null) }
    fun permanentlyDelete(id: Long) = persist(store.loadConversations().filterNot { it.id == id })
    private fun update(id: Long, transform: (Conversation) -> Conversation) = persist(store.loadConversations().map { if (it.id == id) transform(it) else it })
    private fun persist(items: List<Conversation>) = store.saveConversations(items)
}
