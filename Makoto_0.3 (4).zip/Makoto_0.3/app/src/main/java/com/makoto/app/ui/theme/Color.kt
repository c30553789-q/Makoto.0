package com.makoto.app.ui.theme

import androidx.compose.ui.graphics.Color

val MakotoBlack = Color(0xFF09070D)
val MakotoSurface = Color(0xFF121019)
val MakotoSurfaceVariant = Color(0xFF211B2A)
val MakotoPurple = Color(0xFF8B5CF6)
val MakotoLavender = Color(0xFFC4B5FD)
