package com.makoto.app.storage

import android.content.Context
import android.util.AtomicFile
import com.makoto.app.data.ChatMessage
import com.makoto.app.data.Conversation
import com.makoto.app.data.MemoryItem
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets

/**
 * Small, local, crash-safer JSON store.
 * Conversations can grow beyond the practical size of SharedPreferences,
 * so they are kept in app-private files instead.
 */
class JsonStore(context: Context) {
    private val filesDir = context.applicationContext.filesDir
    private val conversationsFile = AtomicFile(File(filesDir, "conversations.json"))
    private val memoryFile = AtomicFile(File(filesDir, "memory.json"))

    @Synchronized
    fun loadConversations(): List<Conversation> = runCatching {
        val raw = read(conversationsFile) ?: return emptyList()
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val msgs = o.optJSONArray("messages") ?: JSONArray()
                val list = buildList {
                    for (j in 0 until msgs.length()) {
                        val m = msgs.getJSONObject(j)
                        add(ChatMessage(m.getLong("id"), m.getString("text"), m.getBoolean("fromUser")))
                    }
                }
                add(
                    Conversation(
                        o.getLong("id"),
                        o.getString("title"),
                        list,
                        if (o.isNull("deletedAt")) null else o.optLong("deletedAt")
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun saveConversations(items: List<Conversation>) {
        val array = JSONArray()
        items.forEach { c ->
            val o = JSONObject().put("id", c.id).put("title", c.title)
            if (c.deletedAt == null) o.put("deletedAt", JSONObject.NULL) else o.put("deletedAt", c.deletedAt)
            val msgs = JSONArray()
            c.messages.forEach { m ->
                msgs.put(JSONObject().put("id", m.id).put("text", m.text).put("fromUser", m.fromUser))
            }
            o.put("messages", msgs)
            array.put(o)
        }
        write(conversationsFile, array.toString())
    }

    @Synchronized
    fun loadMemory(): List<MemoryItem> = runCatching {
        val raw = read(memoryFile) ?: return emptyList()
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(MemoryItem(o.getLong("id"), o.getString("text"), o.getLong("createdAt")))
            }
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun saveMemory(items: List<MemoryItem>) {
        val array = JSONArray()
        items.forEach { m ->
            array.put(JSONObject().put("id", m.id).put("text", m.text).put("createdAt", m.createdAt))
        }
        write(memoryFile, array.toString())
    }

    fun exportMemoryJson(items: List<MemoryItem>): String {
        val array = JSONArray()
        items.forEach { m ->
            array.put(JSONObject().put("id", m.id).put("text", m.text).put("createdAt", m.createdAt))
        }
        return array.toString(2)
    }

    fun importMemoryJson(json: String): List<MemoryItem> = runCatching {
        val array = JSONArray(json)
        buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(
                    MemoryItem(
                        o.optLong("id", System.currentTimeMillis() + i),
                        o.getString("text"),
                        o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun read(file: AtomicFile): String? {
        if (!file.baseFile.exists()) return null
        file.openRead().use { input ->
            return input.readBytes().toString(StandardCharsets.UTF_8)
        }
    }

    private fun write(file: AtomicFile, content: String) {
        var output: java.io.FileOutputStream? = null
        try {
            output = file.startWrite()
            output.write(content.toByteArray(StandardCharsets.UTF_8))
            output.flush()
            file.finishWrite(output)
        } catch (t: Throwable) {
            if (output != null) file.failWrite(output)
            throw t
        }
    }
}
