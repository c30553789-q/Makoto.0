package com.makoto.app.ui.theme

import androidx.compose.material3.Typography

val MakotoTypography = Typography()
