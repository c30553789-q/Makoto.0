# Revisión de Makoto 0.1

## Problemas encontrados en la primera entrega

- El `InferenceEngine` usaba `kotlinx.coroutines.Flow` sin declarar explícitamente la dependencia. Corregido.
- El workflow intentaba ejecutar un `gradlew` que era solo un marcador y no un wrapper real. Corregido: el workflow instala Gradle 8.13 directamente.
- Había dependencias/importaciones que no eran necesarias para esta primera base. Limpiadas.
- La primera entrega describía como "funcional" almacenamiento que todavía eran solo estructuras de datos. La documentación ahora distingue claramente lo implementado de lo pendiente.

## Verificaciones realizadas

- AGP 8.13 <-> Gradle 8.13: compatible según Android Developers.
- JDK 17: compatible con AGP 8.13.
- Compile SDK 36: dentro del máximo soportado por AGP 8.13.
- Compose BOM 2026.09.00: coincide con la recomendación actual de Android Developers.
- Selector de carpeta: usa `ACTION_OPEN_DOCUMENT_TREE`.
- El modelo sigue separado del APK.

## Limitación

No se pudo ejecutar una compilación Android completa dentro de este entorno porque no hay Gradle ni Android SDK instalados localmente. Por eso no voy a afirmar que el APK ya está "100% compilado y probado". El workflow está preparado para hacer esa comprobación en un runner de GitHub.
