package com.makoto.app.model

import com.makoto.app.data.MemoryItem
import com.makoto.app.storage.JsonStore

class MemoryRepository(private val store: JsonStore) {
    fun all(): List<MemoryItem> = store.loadMemory().sortedByDescending { it.createdAt }

    fun add(text: String) {
        val now = System.currentTimeMillis()
        val existing = store.loadMemory()
        val id = maxOf(now, (existing.maxOfOrNull { it.id } ?: 0L) + 1L)
        store.saveMemory(existing + MemoryItem(id, text, now))
    }

    fun delete(id: Long) {
        store.saveMemory(store.loadMemory().filterNot { it.id == id })
    }

    fun exportJson(): String = store.exportMemoryJson(store.loadMemory())

    fun importJson(json: String) {
        store.saveMemory(store.importMemoryJson(json))
    }
}
