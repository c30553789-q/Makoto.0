package com.makoto.app.storage

import android.content.Context

class LocalStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences("makoto_settings", Context.MODE_PRIVATE)

    fun saveModelTreeUri(uri: String) { preferences.edit().putString(KEY_MODEL_TREE_URI, uri).apply() }
    fun getModelTreeUri(): String? = preferences.getString(KEY_MODEL_TREE_URI, null)
    fun clearModelTreeUri() { preferences.edit().remove(KEY_MODEL_TREE_URI).apply() }

    companion object { private const val KEY_MODEL_TREE_URI = "model_tree_uri" }
}
